import { test, expect } from '@playwright/test';
import http from 'node:http';
test('login api', async ({ request }) => {
  const srv = http.createServer((req, res) => { res.setHeader('set-cookie', 'session=SESSIONSECRET123456; HttpOnly'); res.setHeader('content-type','application/json'); res.end(JSON.stringify({ token: 'BODYTOKEN_abcdef123456', user: 'ada' })); });
  await new Promise<void>((r) => srv.listen(0, r));
  const port = (srv.address() as any).port;
  const res = await request.post(`http://127.0.0.1:${port}/login?api_key=QUERYKEY987654`, {
    headers: { Authorization: 'Bearer HEADERTOKEN_zyx987654', cookie: 'sid=COOKIESECRET555' },
    data: { username: 'ada', password: 'PLAINPASSWORD42' },
  });
  expect(res.status()).toBe(200);
  console.log('log line with secret CONSOLESECRET777');
  srv.close();
});
